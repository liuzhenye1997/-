define([
  'common',
  'text!templates/bgkConfig-template.html'

], function (common, bgkConfigTemplate) {

  var BkgConfigView = Backbone.View.extend({
    el: $("#bgkModalPlace"),
    template: _.template(bgkConfigTemplate),
    initialize: function (options) {
      this.$el.html(this.template);
      this.eventBus = options.eventBus;
      this.render();
    },

    events: {
      'click .default-bgk': 'setBgk',
      'click .default-bgkPure': 'setBgkPure',
      'click .close': 'cancel',
      'click #cancel': 'cancel',
      'click #apply': 'apply'
    },

    render: function () {
      var _self = this;
      this.$el.find('#bgkModal').modal('show');

      // this.$el.find('#bgkModal').on('hide.bs.modal', function (e) {
      //   _self.cancel();
      // });

      /** 拖拽模态框*/
      var dragModal = {
        mouseStartPoint: {"left": 0, "top": 0},
        mouseEndPoint: {"left": 0, "top": 0},
        mouseDragDown: false,
        basePoint: {"left": 0, "top": 0},
        moveTarget: null,
        topleng: 0
      };

      $(document).on("mousedown", ".modal-header", function (e) {
        //webkit内核和火狐禁止文字被选中
        $('body').addClass('select')
        //ie浏览器禁止文字选中
        document.body.onselectstart = document.body.ondrag = function () {
          return false;
        };
        if ($(e.target).hasClass("close"))//点关闭按钮不能移动对话框
          return;
        dragModal.mouseDragDown = true;
        dragModal.moveTarget = $(this).parent().parent();
        dragModal.mouseStartPoint = {"left": e.clientX, "top": e.pageY};
        dragModal.basePoint = dragModal.moveTarget.offset();
        dragModal.topLeng = e.pageY - e.clientY;
      });
      $(document).on("mouseup", function (e) {
        dragModal.mouseDragDown = false;
        dragModal.moveTarget = undefined;
        dragModal.mouseStartPoint = {"left": 0, "top": 0};
        dragModal.basePoint = {"left": 0, "top": 0};
      });
      $(document).on("mousemove", function (e) {
        if (!dragModal.mouseDragDown || dragModal.moveTarget == undefined) return;
        var mousX = e.clientX;
        var mousY = e.pageY;
        if (mousX < 0) mousX = 0;
        if (mousY < 0) mousY = 25;
        dragModal.mouseEndPoint = {"left": mousX, "top": mousY};
        var width = dragModal.moveTarget.width();
        var height = dragModal.moveTarget.height();
        var clientWidth = document.body.clientWidth;
        var clientHeight = document.body.clientHeight;
        if (dragModal.mouseEndPoint.left < dragModal.mouseStartPoint.left - dragModal.basePoint.left) {
          dragModal.mouseEndPoint.left = 0;
        }
        else if (dragModal.mouseEndPoint.left >= clientWidth - width + dragModal.mouseStartPoint.left - dragModal.basePoint.left) {
          dragModal.mouseEndPoint.left = clientWidth - width - 38;
        } else {
          dragModal.mouseEndPoint.left = dragModal.mouseEndPoint.left - (dragModal.mouseStartPoint.left - dragModal.basePoint.left);//移动修正，更平滑

        }
        if (dragModal.mouseEndPoint.top - (dragModal.mouseStartPoint.top - dragModal.basePoint.top) < dragModal.topLeng) {
          dragModal.mouseEndPoint.top = dragModal.topLeng;
        } else if (dragModal.mouseEndPoint.top - dragModal.topLeng > clientHeight - height + dragModal.mouseStartPoint.top - dragModal.basePoint.top) {
          dragModal.mouseEndPoint.top = clientHeight - height - 38 + dragModal.topLeng;
        }
        else {
          dragModal.mouseEndPoint.top = dragModal.mouseEndPoint.top - (dragModal.mouseStartPoint.top - dragModal.basePoint.top);
        }
        dragModal.moveTarget.offset(dragModal.mouseEndPoint);
      });
      $(document).on('hidden.bs.modal', '.modal', function (e) {
        $('.modal-dialog').css({'top': '0px', 'left': '0px'});
        $('body').removeClass('select');
        document.body.onselectstart = document.body.ondrag = null;
      });

      this.selectImg($('#upload'));
    },

    setBgk: function (e) {
      var $target = $(e.target);
      var $parent = $target.parents('.modal-body');
      $parent.find('.default-bgk, .default-bgkPure').css('border', 'solid 2px #999');
      $parent.find('.default-bgk, .default-bgkPure').removeClass('selectedBgk');
      $target.addClass('selectedBgk');
      $target.css('border', 'solid 2px red');

      $('body.e-home-bg1').css('background-color', '');
      $('body.e-home-bg1').css('background-image', '');
      $('body.e-home-bg1').css('background-image', $target.css('background-image'));

    },
    setBgkPure: function (e) {
      var $target = $(e.target);
      var $parent = $target.parents('.modal-body');
      $parent.find('.default-bgkPure, .default-bgk').css('border', 'solid 2px #999');
      $parent.find('.default-bgk, .default-bgkPure').removeClass('selectedBgk');
      $target.addClass('selectedBgk');
      $target.css('border', 'solid 2px red');

      $('body.e-home-bg1').css('background-image', '');
      $('body.e-home-bg1').css('background-color', '');
      $('body.e-home-bg1').css('background-color', $target.css('background-color'));
    },
    cancel: function () {
      var $parent = this.$el.find('.default-bgk-container');
      $parent.find('.default-bgk, .default-bgkPure').removeClass('selectedBgk');
      var bodyBgkArr = window.localStorage.getItem('bodyBgk').split('||');
      if ('background-image' == bodyBgkArr[0]) {
        $('body.e-home-bg1').css(bodyBgkArr[0], "url(\'" + window.CONTEXT_PATH + bodyBgkArr[1] + "\')")
      }
      $('body.e-home-bg1').css(bodyBgkArr[0], bodyBgkArr[1])

    },
    apply: function () {
      var $selected = $('.selectedBgk');
      var cssAttr = 'background-image';
      var cssVal = '';

      if ($selected.hasClass('bgkPure')) {
        cssAttr = 'background-color';
        cssVal = $selected.css(cssAttr);
      } else {
        cssAttr = 'background-image';
        cssVal = $selected.attr("data-url");
      }

      var type = '';
      var fd = new FormData();
      if (this.$el.find("#upload")[0].files[0]) {
        if (this.$el.find("#upload")[0].files[0].size / 1024 / 1024 > 20) {
          bootbox.alert('只支持上传小于20M的图片！');
          return false;
        }
        fd.append("portraitFile", this.$el.find("#upload")[0].files[0]);
        type = 'uploadBgk'
      } else {
        fd.append("portraitFile", this.$el.find("#upload")[0].files[0]);

        type = cssAttr + '||' + cssVal
      }
      fd.append("type", type);

      $.ajax({
        url: window.CONTEXT_PATH + '/account/background-photo-apply',
        data: fd,
        contentType: false,
        processData: false,
        type: 'POST',
        success: function (res) {
          if (!res.success) {
            window.location.href = window.CONTEXT_PATH + "/redirect?REDIRECT_URL=home" +
                "&success=" + res.success + "&type=" + res.type + "&content=" + res.content;
          } else {
            window.localStorage.setItem('bodyBgk', type);
          }
        }
      });
    },

    selectImg: function (fileInputs) {
      var _self = this;
      var checkImg = new RegExp("(.jpg$)|(.png$)|(.jpeg$)", "i");
      var i = 0;
      for (; i < fileInputs.length; i++) {
        (function (i) {//立即执行函数；保存i
          fileInputs[i].onchange = function () {
            if (checkImg.test(fileInputs[i].value)) {
              _self.previewImg(this);
            } else {
              bootbox.alert("只支持上传.jpg .png  .jpeg;你的选择有误");
            }
          };
        })(i);
      }

    },
    previewImg: function (fileInput) {
      var reader = new FileReader();
      reader.readAsDataURL(fileInput.files[0]);
      reader.onload = function (evt) {
        $('.e-home.e-home-bg1').css('background-image', 'url(' + evt.target.result + ')')
      }
    }
  });

  return BkgConfigView;
});