/**
 * Created by wx on 18-5-30.
 */
define([], function () {
  var portraitData = {
    getPortrait: function () {
      var imageData = ''

      $.ajax({
        url: window.CONTEXT_PATH + '/account/get-avatar',
        async: false,
        type: "GET",
        success: function (res) {
          imageData = res
        }

      });
      return imageData;
    }
  }
  return portraitData;
})