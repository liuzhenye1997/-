/**
 * Created by wx on 17-3-26.
 */
define([
  'common',
  'text!templates/shortcutMenu-template.html'
], function (common, MenuTemplate) {
  'use strict';

  var shortcutMenuView = Backbone.View.extend({
    tagName: 'li',
    className: 'view form-control',
    template: _.template(MenuTemplate),
    initialize: function (options) {
      this.$el.html(this.template);
      this.$el.attr('draggable',true);
      this.$el.attr('id','selected-'+options.viewId);
      this.title = options.title;
      this.shortcuts = options.shortcuts;
      this.viewId = options.viewId;
      this.eventBus = options.eventBus;
      this.$el.find('label').html(this.title);
    },

    events: {
      'click .destroy': 'delete',
      'dragstart': "dragStart",
      "dragend": "dragEnd",
      "dragover": "dragOver",
      "drop":'drop'
    },
    dragStart:function (e) {
      e.originalEvent.dataTransfer.setData("Text",e.target.id);
      common.shortcutMenuMoveView = this.$el;
      this.$el.css('border','dashed #ccc 1px')

    },
    dragOver:function (e) {
      e.preventDefault();
      e.originalEvent.dataTransfer.dropEffect = 'move';
      this.$el.parents('#menuBasket').find('li').css('border','solid #ccc 1px');
      this.$el.css('border','dashed #ccc 1px')
    },

    dragEnd:function (e) {

      e.preventDefault();
      this.$el.parents('#menuBasket').find('li').css('border','solid #ccc 1px');

      },
    drop:function (e) {
      e.preventDefault();

      e.stopPropagation();//火狐浏览器拖拽出现新的标签页
      var $target = $(e.target);

      var $targetLi = e.target.nodeName == 'LI' ? $target : $target.parents('li');

      var data=e.originalEvent.dataTransfer.getData("Text");
      $targetLi.before($('li[id="'+data+'"]'));
      this.$el.parents('#menuBasket').find('li').css('border','dashed gray 0px');

      var srcIndex = 0;
      var goalIndex = 0;
      this.shortcuts.models.map(function (value ,i) {
        if( 'selected-'+value.id == data ){
          srcIndex = i
        }
        if($targetLi.attr('id') == 'selected-' +value.id ){
          goalIndex = i
        }
      });
      var needInsert =  this.shortcuts.models[srcIndex];

      this.shortcuts.models.splice(srcIndex , 1);
      this.shortcuts.models.splice(goalIndex , 0, needInsert);
    },

    delete: function () {
      this.eventBus.trigger('shortcut:delete', this.viewId, 'delete')
    }

  });
  return shortcutMenuView;
})