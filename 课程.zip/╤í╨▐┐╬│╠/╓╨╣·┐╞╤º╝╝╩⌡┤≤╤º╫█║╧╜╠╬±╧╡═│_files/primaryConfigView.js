define([
      'common',
      'text!templates/primaryConfig-template.html',
      'services/primaryMenuService'
    ],
    function (common, PrimaryConfigTemplate, primaryMenuService) {
      var PrimaryConfigView =  Backbone.View.extend({
        el: $("#primaryModalPlace"),
        template: _.template(PrimaryConfigTemplate),
        initialize:function (options) {
          this.eventBus = options.eventBus;
          this.bizTypeId = options.bizTypeId;
          this.menus = options.menus;
          this.initPrimaryCodes = options.initPrimaryCodes;
          this.$el.html(this.template());
          this.listenTo(this.eventBus, 'primarySetting:show', this.show);
        },

        render:function (biztypeId, codeList) {
          var _self = this;
          biztypeId ? _self.bizTypeId = biztypeId : '';

          this.initPrimaryCodes = primaryMenuService.getPermCodes(biztypeId);

          var $ul = this.$el.find('ul.primaryConfigList');
          $ul.empty();
          var lis = '';
          var codeArray = codeList || _self.initPrimaryCodes;
          if(codeArray.length && codeArray[0].indexOf("displayNum")>-1){
              var displayNum = codeArray.shift().split('-')[1];
              this.$el.find("input[name='display'][value='"+displayNum+"']").attr("checked","checked");
          }

          common.sortedPrimaryMenu(_self.menus,codeArray).forEach(function (menu, index) {

            var li = '<li draggable="true" class="primaryConfigLi list-group-item" data-Code="' + menu.id + '" id="primary-' + menu.id + '"><i class="fa fa-bars" style="margin-right: 10px"></i><span>' + menu.title + '</span></li>';
            lis += li;

          });

          $ul.append($(lis));

        },
        show:function (biztypeId, codeList) {
          this.render(biztypeId, codeList);
          this.$el.find('#primarySettingModal').modal('show')
        },
        events:{
          'dragstart .primaryConfigLi': "dragStart",
          "dragend .primaryConfigLi": "dragEnd",
          "dragover .primaryConfigLi": "dragOver",
          "drop .primaryConfigLi":'drop',
          "click #save":'save',
          "click #default-setting":'defaultSetting'
        },

        dragStart:function (e) {
          e.originalEvent.dataTransfer.setData("Text",e.target.id);
          $(e.target).css('border','dashed gray 1px')

        },
        dragOver:function (e) {
          e.preventDefault();
          var $target = $(e.target);

          // e.stopPropagation();
          e.originalEvent.dataTransfer.dropEffect = 'move';
          var $targetLi = e.target.nodeName == 'LI' ? $target : $target.parents('li');
          $targetLi.parents('.primaryConfigList').find('li').css('border','solid #ddd  1px');
          $targetLi.css('border','dashed #ddd 1px');

        },

        dragEnd:function (e) {
          var $target = $(e.target);

          e.preventDefault();
          var $targetLi = e.target.nodeName == 'LI' ? $target : $target.parents('li');
          $targetLi.parents('.primaryConfigList').find('li').css('border','solid #ddd  1px');
          $targetLi.css('border','solid #ddd  1px');

        },
        drop:function (e) {
          e.preventDefault();
          e.stopPropagation();//火狐浏览器拖拽出现新的标签页

          var $target = $(e.target);

          var $targetLi = e.target.nodeName == 'LI' ? $target : $target.parents('li');
          var data=e.originalEvent.dataTransfer.getData("Text");
          $targetLi.before($('li[id="'+data+'"]'));
          $target.parents('.primaryConfigList').find('li').css('border','solid #ddd 1px');

        },
        save:function (e) {
          var codeList =[];

          this.$el.find('.primaryConfigList li').each(function (index, li) {
            var $li = $(li);
            codeList.push($li.attr('data-Code'))
          });

          var displayNum = this.$el.find("input[name='display']:checked").val();

          codeList.unshift('displayNum-'+displayNum);

          var _self = this;

          $.ajax({
            url: window.CONTEXT_PATH + '/home/save-account-menu-primary',
            type: "POST",
            data: {
              bizTypeId: _self.bizTypeId,
              permCodes: codeList.join(","),
              REDIRECT_URL: '/home'
            },
            success: function () {
              _self.eventBus.trigger('primaryConfig:save', _self.bizTypeId, codeList);
              $("#primarySettingModal").modal('hide');
            }
          });

        },

        defaultSetting: function (e) {

          this.render(this.bizTypeId , [])
        }
      })
      return PrimaryConfigView
    })