define([], function () {
  var common = {
    shortcutMenuMoveView:null,
    primaryMenuMoveView:null,
    sortedPrimaryMenu:function (menus, codeList) {
      var result = [];
      var _self = this;
      codeList = _self.getPrimaryCode(codeList, menus);//menus里面新增了Primary 可是codeList里面没有

      codeList.forEach(function (code, index) {
        var subMenus = []
        for (var i = 0; i < menus.length; i++) {
          var menu = menus[i]
          var existChild = menus.some(function (childNode) {
            return childNode.parentId === menu.id
          })

          subMenus = existChild ? _self.getSubMenus(menus, menu.id) : []
          menus[i]['subMenus'] = subMenus;

          if (menu.parentId === '' && menu.id === code) {
            result.push(menu);
          }
        }
      });
      return result;
    },

    getPrimaryCode: function (codeList, menus) {

      menus.forEach(function (menu) {
        if(menu.parentId === "" && codeList.indexOf(menu.id) === -1){
          codeList.push(menu.id)
        }
      })
      return codeList;
    },

    getSubMenus: function (menus, menuId) {
      var subMenu=[];
      menus.forEach(function (menu, index) {
        menu['subMenus'] =[]
        menus.forEach(function (item, index) {
          item.parentId == menu.id ?
              menu['subMenus'].push(item) :'';
        })
        if(menu.parentId == menuId){
          subMenu.push(menu)
        }
      });
      return subMenu;
    },

  }
  return common;
});