define([
      'views/primaryView',
      'services/primaryMenuService',
      'views/primaryConfigView',
      'common'
    ],
    function (primaryView, primaryMenuService, primaryConfigView, common) {
      var primaryMenusView = Backbone.View.extend({
        el: $('.primary-container'),
        initialize: function (options) {
          this.bizTypeId = options.bizTypeId;
          this.eventBus = options.eventBus;
          this.menus = options.menus;
          this.initPrimaryCodes = options.initPrimaryCodes;

          this.listenTo(this.eventBus, 'primaryConfig:save', this.render);
          this.$el.on("slide.bs.carousel", function () {
            $(this).find(".carousel-inner").addClass("overflow-hidden");
          });
          this.$el.on("slid.bs.carousel", function () {
            $(this).find(".carousel-inner").removeClass("overflow-hidden");
          });
        },
        render: function (biztypeid, codeList) {
          var _self = this;
          _self.$el.find('.left').show();
          _self.$el.find('.right').show();

          if (biztypeid != undefined) {
            _self.bizTypeId = biztypeid
          }

          _self.$el.find('.primary').empty();
          var num = 0, displayNum = 5;
          codeList = codeList || _self.initPrimaryCodes;
          if (codeList.length && codeList[0].indexOf("displayNum") > -1) {
            displayNum = codeList.shift().split('-')[1];
            $("#primaryCarousel").attr("data-display", displayNum);
          }
          var sortedmenus = codeList ? common.sortedPrimaryMenu(_self.menus, codeList) : _self.menus;
          sortedmenus.forEach(function (item, index) {

            var primary = new primaryView({
              subMenus: item.subMenus,
              menu: item,
              num: index,
              eventBus: _self.eventBus
            });

            if (num % displayNum == 0) {
              num == 0 ? _self.$el.find('.primary').append('<div class="item active"><ul class="primaryLi-container"></ul></div>') : _self.$el.find('.primary').append('<div class="item"><ul class="primaryLi-container"></ul></div>');
            }
            _self.$el.find('.primary').find('.item>ul').eq(Math.floor(num / displayNum)).append(primary.$el);


            if (item.subMenus.length == 0) {
              primary.$el.find('.primary-img-hover').remove();
              primary.$el.find('.subMenus').remove();
              primary.$el.removeClass('hasSubMenus');
            }

            num++;
          })
        },
        events: {
          'click .left': 'left',
          'click .right': 'right'
        },
        left: function () {
          // this.$el.find('.right').show();
          if (this.$el.find('.item').eq(0).hasClass('active')) {
            return false;
          }
          // this.$el.find('.right').show();


        },
        right: function () {
          // this.$el.find('.left').show();
          var num = this.$el.find('.item').length;
          if (this.$el.find('.item').eq(num - 1).hasClass('active')) {
            return false;
          }
          // this.$el.find('.left').show();

        }
      });
      return primaryMenusView;
    })