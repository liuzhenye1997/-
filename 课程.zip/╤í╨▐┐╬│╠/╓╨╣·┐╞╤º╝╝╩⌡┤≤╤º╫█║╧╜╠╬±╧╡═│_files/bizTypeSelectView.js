/**
 * Created by wx on 17-4-10.
 */
define([
  'text!templates/bizTypeSelect-template.html'
], function (BizTypeSelectTemplate) {

  var BizTypeSelectView = Backbone.View.extend({

    el: $('#bizTypeSelectPlace'),
    template: _.template(BizTypeSelectTemplate),
    initialize: function (options) {
      this.bizType = options.bizType;
      this.bizTypes = options.bizTypes;
      this.eventBus = options.eventBus;
      this.render();
    },
    render: function () {
      var _self = this;
      // this.$el.html(this.template);
      var bizTypes = _self.bizTypes;
      var swithStr = {
        zh: '切换业务类型',
        en: 'Switch BizType'
      };
      var switchLan = {
        zh:'Zh',
        en:'En'
      }
      $("#home_change_id_biz").html(swithStr[window.LOCALE]);

      $.each(bizTypes, function () {
        if (this.id == _self.bizType.id) {
          _self.$el.append("").append('<li><a href="#" bizTypeId ="' + this.id + '" class="list-item"><span bizTypeId ="' + this.id + '" >' + _self.getI18nName(this) + '</span></a></li>');
          $(".role-change-div").find("span").text(this['name'+switchLan[window.LOCALE]]);
        } else {
          _self.$el.append("").append('<li><a href="#" bizTypeId ="' + this.id + '" class="list-item"><span bizTypeId ="' + this.id + '" >' + _self.getI18nName(this) + '</span></a></li>');
        }
      });
    },
    events: {
      'click .list-item': 'changeBizType'
    },
    changeBizType: function (event) {
      var $this = $(event.target);
      var $list;
      var currentBizTypeId = $this.attr("bizTypeId");

      $(".list-group-item.selected").removeClass("selected");

      if ($this.hasClass('list-group-item')) {
        $list = $this;
      } else {
        $list = $this.parents('.list-group-item');
      }
      $list.addClass('selected');

      // $("#bizTypeSwitcher").modal('hide');

      $(".role-change span").text($this.text().trim());

      if (currentBizTypeId != this.bizType.id) {
        this.eventBus.trigger('bizType:change', currentBizTypeId, event);
        this.bizType.id = currentBizTypeId;
        this.bizType.name = $this.text().trim();
        $.post({
          url: window.CONTEXT_PATH + '/individual-setting/save-setting',
          data: JSON.stringify(["navigation-bizType",currentBizTypeId]),
          contentType: "application/json",
          success: function (res) {
          }
        });
      }
    },
    getI18nName: function (model) {
      if (window.LOCALE == 'zh') {
        return _.escape(model.nameZh);
      } else {
        return (model.nameEn ? _.escape(model.nameEn) : _.escape(model.nameZh));
      }
    }
  });
  return BizTypeSelectView;

});