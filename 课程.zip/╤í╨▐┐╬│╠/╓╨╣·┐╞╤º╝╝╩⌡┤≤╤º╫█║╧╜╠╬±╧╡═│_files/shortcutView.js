/**
 * Created by wx on 17-3-24.
 */
define([
  'models/shortcut',
  'collections/shortcuts',
  'views/shortcutConfigView',
  'services/shortcutService'
], function (Shortcut, Shortcuts, ShortcutConfigView, ShotcutService) {

  var ShortcutView = Backbone.View.extend({
    el: $("#shortcut"),
    initialize: function (options) {

      this.eventBus = options.eventBus;
      this.bizTypeId = options.bizTypeId;
      this.menus = options.menus;
      this.listenTo(this.eventBus, 'shortcut:save',this.refreshShortcut);
      this.listenTo(this.eventBus, 'shortcut:show', this.config);

      this.configView = new ShortcutConfigView({
        menus: this.menus,
        shortcuts: this.initShortcuts,
        eventBus: this.eventBus
      });
    },
    render: function (biztypeid) {
      var _self = this;

      if (biztypeid != undefined) {
        _self.bizTypeId = biztypeid
      }

      var permCodes = ShotcutService.getPermCodes(_self.bizTypeId);
      var shortcuts = new Shortcuts;

      $.each(permCodes, function (index, value) {
        _.map(_self.menus, function (menu) {
          if (menu.permCode == value) {
            var shortcut = new Shortcut({
              id: menu.id,
              title: menu.title,
              href: menu.href,
              permCode: menu.permCode
            });
            shortcuts.add(shortcut);
          }
        })
      });
      this.refreshShortcut(shortcuts);
      
      return this;
    },
    refreshShortcut: function (shortcuts) {
      var _self = this;
      _self.initShortcuts = shortcuts;

      $("#shortcut").empty();
      this.$el.html(this.template);

      $.each(_self.initShortcuts.models, function () {
        $("#shortcut").append('<a class="shortcutDiv text-center" id="drop_' + this.get("id") + '" href="' + this.get("href") + '">' + this.get("title") + '</a><input class="hidden" value="' + this.get("id") + '"/>');
      });
      if(_self.initShortcuts.models.length < 8){
        $("#shortcut").append('<a id="shortcutConfig"> <i class="fa fa-2x fa-plus"></i><p>添加快捷入口</p></a>')
        $("#shortcut .shortcutConfig").click(function () {
          _self.config();
        })
      }else{
        $("#shortcut .shortcutConfig").remove();
      }
    },
    events: {
      'click #shortcutConfig': 'config',
      'click .shortcutDiv': 'clickShortcut'
    },
    config: function () {
      var _self = this;
      this.configView.$el.empty();
      this.configView.menus = _self.menus;
      this.configView.bizTypeId = _self.bizTypeId;
      this.configView.eventBus = _self.eventBus;
      this.configView.shortcuts = _self.initShortcuts;

      this.configView.render();
    },
    clickShortcut: function (e) {
      var $this = $(e.target);
      this.eventBus.trigger('shortcut:click', $this, e);
    }

  });
  return ShortcutView;
});
