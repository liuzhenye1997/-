/**
 * Created by wx on 17-3-24.
 */
var refreshViews = function (bizType, bizTypes, personName, hasAvatar, defaultAvatar,finereportTargetUrl) {

  require.config({
    baseUrl: window.CONTEXT_PATH + '/static/home/js',

    paths: {
      text: window.CONTEXT_PATH + '/static/eams-ui/js/text'
    }
  });
  require([
    'services/menuService',
    'views/bizTypeSelectView',
    'views/menuView',
    'views/toolbarTabView',
    'views/accountManagementView',
      'common'
  ], function (menuService, BizTypeSelectView, MenuView, ToolbarTabView, AccountManagementView , common) {

    var eventBus = _.extend({}, Backbone.Events);
    if(!bizType){
      bizType = {id:null}
    }
    // bizType = {id:2};
    var menuView = new MenuView({
      eventBus: eventBus,
      bizType: bizType
    });
    var toolbarTabView = new ToolbarTabView({
      eventBus: eventBus
    });

    var bizTypeSelectView = new BizTypeSelectView({
      bizType: bizType,
      bizTypes: bizTypes,
      eventBus: eventBus
    });

    $(".role-change").click(function () {
      $("#bizTypeSwitcher").modal('show');
    });

    var accountManagementView = new AccountManagementView({
      eventBus: eventBus,
      personName: personName,
      bizTypeId: bizType.id,
      hasAvatar: hasAvatar,
      defaultAvatar: defaultAvatar,
      finereportTargetUrl:finereportTargetUrl
    });

    (function resizeToolbarView() {
      var $toolbarView = $(".toolbarView");
      var width = $(".e-header .navbar-collapse").outerWidth();
      $toolbarView.siblings("ul").each(function (index, item) {
        width -= $(item).outerWidth();
      });
      $toolbarView.width(width - 20);
    })()



  });

};
