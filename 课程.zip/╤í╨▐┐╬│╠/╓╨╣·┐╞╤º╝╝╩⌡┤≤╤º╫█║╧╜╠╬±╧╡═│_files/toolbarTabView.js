/**
 * Created by wx on 17-4-12.
 */
define([
  'views/tabView',
  'text!templates/toolbarTab-template.html'
], function (TabView, ToolbarTabTemplate) {

  var ToolbarTabView = Backbone.View.extend({
    el: $(".toolbarView"),
    template: _.template(ToolbarTabTemplate),
    initialize: function (options) {
      this.eventBus = options.eventBus;
      this.listenTo(this.eventBus, 'menu:activated', this.addOne);
      this.listenTo(this.eventBus, 'fixedMenu:activated', this.addOne);
      this.listenTo(this.eventBus, 'shortcut:click', this.addOne);
      this.listenTo(this.eventBus, 'primarySubMenu:click', this.addOne);
      this.listenTo(this.eventBus, 'activate:hometab', this.getHomePage);
      this.listenTo(this.eventBus, 'bizType:change', this.resizeToolbarView);
      this.$el.html(this.template);
      this.iframeId = 0;
    },
    events: {
      'click #scroll-right': 'scrollRight',
      'click #scroll-left': 'scrollLeft',
      'click #e-home-tab-home': 'getHomePage'
    },
    getHomePage: function (e) {
      e.preventDefault();
      var $iframeContainer = $('#e-op-area .e-op-area-iframe-container');
      var $container = $("#e-top-menu");
      var $tabList = $('#e-home-tab-list');
      var $nav = $("nav.navbar");

      /*改变nav背景*/
      $nav.addClass("home-active");

      $iframeContainer.find("#home-loading").addClass('hide');
      $iframeContainer.find("#home-page").removeClass('hide');
      $iframeContainer.css('background-color', 'transparent');

      $iframeContainer.find('iframe').addClass("v-hidden");
      $tabList.find('li').removeClass('active');
      $("#e-home-tab-home").parents('li').addClass('active');
      this.eventBus.trigger('tab:activated', $container.find("a[target=e-home-iframe]"));
    },
    scrollRight: function () {
      var tabMargin = 0;
      var header_max_width = $(".e-page-header").width();
      var header_offset_left = $(".e-page-header").offset().left;
      var $beyond_right_border_li = null;
      $.each(this.$el.find('#e-home-tab-list').find("li"), function () {
        var current_width = $(this).offset().left + $(this).outerWidth();
        if (current_width > header_max_width + header_offset_left) {
          $beyond_right_border_li = $(this).next();
          if (!$beyond_right_border_li.length) {
            $beyond_right_border_li = $(this);
          }
          return false;
        }
      });

      if ($beyond_right_border_li) {
        var offset_left = header_offset_left + header_max_width - ($beyond_right_border_li.offset().left + $beyond_right_border_li.outerWidth() + tabMargin);
        $("div#e-home-tab-list:not(:animated)").animate({left: '+=' + (offset_left + 'px')});
      }

    },
    scrollLeft: function () {

      var tabMargin = 8;
      var header_offset_left = $(".e-page-header").offset().left;
      var leftOffset = this.$el.find('#e-home-tab-list').offset().left;
      if (leftOffset >= header_offset_left + 10) {// margin-left:10px;
        return false;
      }

      var left_border_index = 0;
      $.each(this.$el.find("li"), function () {
        if ($(this).offset().left >= header_offset_left) {
          left_border_index = $(this).index();
          return false;
        }
      });

      var $beyond_left_border_li = this.$el.find("li:nth-child(" + (left_border_index - 1) + ")");
      if (!$beyond_left_border_li.length) {
        $beyond_left_border_li = this.$el.find("li:nth-child(" + (left_border_index - 1 + 1) + ")");
      }
      if ($beyond_left_border_li && $beyond_left_border_li.length) {
        var offset_left = header_offset_left - $beyond_left_border_li.offset().left;
        $("div#e-home-tab-list:not(:animated)").animate({left: '+=' + (offset_left + 'px')});
      }

    },
    scrollLast: function () {
      var tabMargin = 0;
      var header_max_width = $(".e-page-header").width();
      var header_offset_left = $(".e-page-header").offset().left;
      var $lastLi = this.$el.find('#e-home-tab-list li:last');
      var offset_left = header_offset_left + header_max_width - ($lastLi.offset().left + $lastLi.outerWidth() + tabMargin);
      $("div#e-home-tab-list:not(:animated)").animate({left: '+=' + (offset_left + 'px')});
    },
    addOne: function ($anchor, event, queryString) {
      var _self = this;
      var $iframeContainer = $('#e-op-area .e-op-area-iframe-container');
      var tabAnchor = 'a[target]:not(.e-tab-close-icon)';

      /*改变nav背景*/
      var $nav = $("nav.navbar");
      $nav.removeClass("home-active");

      var src = $anchor.attr('href');
      var tabMargin = 0;

      if ($('#e-home-tab-home').length == 0) {
        this.$el.find("#e-home-tab-list").append('<li class="tabLi active"><a href="welcome/" id="e-home-tab-home" target="e-home-iframe"> 首页 </a> </li>');
      }
      var maxWidth = $(".e-page-header").width() - tabMargin * 2;

      var srcNoQueryString = src.indexOf('?') == -1 ? src : src.substring(0, src.indexOf('?'));
      var $frames = $iframeContainer.find('iframe[src^="' + srcNoQueryString + '"]');
      var $existIframe = {length: 0};
      queryString ? src = srcNoQueryString + queryString : '';

      $frames.each(function (index, item) {
        var _src = $(item).attr("src");
        var _srcNoQueryString = _src.indexOf("?") === -1 ? _src : _src.substring(0, _src.indexOf("?"));
        if (_srcNoQueryString == srcNoQueryString) {
          $existIframe = $(item);
          return false;
        }

      });
      /*
       * 如果存在相同url的iframe
       *   将anchor的target指向新的那个iframe
       *   将那个iframe显示出来
       *   激活对应的tab
       */
      if ($existIframe.length > 0) {
        $iframeContainer.find('iframe:not(:hidden)').addClass("v-hidden");
        $existIframe.removeClass("v-hidden");
        $existIframe.attr('src', src);

        var $tabAnchor = this.$el.find('#e-home-tab-list').find(tabAnchor).filter("[target='" + $existIframe.attr('name') + "']");

        this.$el.find('#e-home-tab-list').find(tabAnchor).parents('li').removeClass('active');
        $tabAnchor.parent('li').addClass('active');

        //不保留之前的页面
        $($existIframe[0].contentDocument).find('.index').remove();
        return;
      }

      var newBlankUrl = ['/webroot'];
      for(var i=0;i<newBlankUrl.length;i++){
        if ($anchor.attr('href').search(newBlankUrl[i]) != -1) {
          window.open($anchor.attr('href'), '_blank');
          return;
        }
      }

      this.iframeId++;
      $anchor.attr('href', src)
      var tabView = new TabView({
        iframeId: _self.iframeId,
        href: $anchor.attr('href'),
        eventBus: _self.eventBus,
        event: event,
        target: $anchor

      });

      this.$el.find('#e-home-tab-list').append(tabView.$el);
      if (this.$el.find('#e-home-tab-list').width() > maxWidth) {
        $("#scroll-right").show();
        $("#scroll-left").show();
        _self.scrollLast()
      }
      $("body").scrollTop(0);

    },
    resizeToolbarView: function () {
      var $toolbarView = $(".toolbarView");
      var width = $(".e-header .navbar-collapse").outerWidth();
      $toolbarView.siblings("ul").each(function (index, item) {
        width -= $(item).outerWidth();
      });
      $toolbarView.width(width - 20);
    }
  });
  return ToolbarTabView;

});