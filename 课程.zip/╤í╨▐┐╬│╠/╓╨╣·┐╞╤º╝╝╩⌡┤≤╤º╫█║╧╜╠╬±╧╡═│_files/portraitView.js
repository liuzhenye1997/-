define([
    'common',
  'text!templates/portraitConfig-template.html'

], function (common, portraitConfigTemplate) {

  var PortraitView = Backbone.View.extend({
    el: $("#portraitModalPlace"),
    template: _.template(portraitConfigTemplate),
    initialize: function (options) {
      this.$el.html(this.template);
      this.eventBus = options.eventBus;
      this.render();
    },

    events: {
      'click #cancel': 'cancel',
      'click #apply': 'apply'
    },

    render: function () {
      this.$el.find('#portraitModal').modal('show');
      this.selectImg($('#upload'),$('.image-show'));
    },
    apply: function () {
      $.ajax({
        url: window.CONTEXT_PATH +'/account/save-avatar',
        data: {
          'blob':$('.image-result').find('img').attr('data-blob')
        },
        type: 'POST',
        success: function (res) {
          window.location.href = window.CONTEXT_PATH + "/redirect?REDIRECT_URL=home" +
              "&success=" + res.success + "&type=" + res.type + "&content=" + res.content;
        }
      });
    },

    selectImg: function (fileInputs,imgDivs){
      var _self = this;
    var checkImg=new RegExp("(.jpg$)|(.png$)|(.bmp$)|(.jpeg$)","i");
    var i=0;
    for(;i<fileInputs.length&&i<imgDivs.length;i++){
      (function(i){//立即执行函数；保存i
        fileInputs[i].onchange=function(){
          if(checkImg.test(fileInputs[i].value)){
            _self.previewImg(this,imgDivs[i]);
          }else{
            bootbox.alert("只支持上传.jpg .png .bmp .jpeg;你的选择有误");
          }
        };
      })(i);
    }

  },
    popupResult: function (result) {
      $('.image-result').html('<img  data-blob="'+result.src+'" src="'+result.src+'"/>')
  },

    previewImg: function (fileInput, imgDiv) {
      var _self = this;
      var reader = new FileReader();
      reader.readAsDataURL(fileInput.files[0]);
      reader.onload = function (evt) {

        _self.$croppie ?  _self.$croppie.croppie('destroy'): '';

        _self.$croppie = $(imgDiv).croppie({
          viewport: {
            width: 200,
            height: 200,
            type: 'circle'
          },
          showZoomer: false
        });

        _self.$croppie.croppie('bind', {
          url: evt.target.result
        });

        $(imgDiv).on('update.croppie', function (ev, cropData) {
          _self.$croppie.croppie('result', {
            type: 'base64',
            size: 'viewport',
            format:'png'
          }).then(function (resp) {
            _self.popupResult({
              src: resp
            })

          });

        });
      }

    }

  })

  return PortraitView;
})