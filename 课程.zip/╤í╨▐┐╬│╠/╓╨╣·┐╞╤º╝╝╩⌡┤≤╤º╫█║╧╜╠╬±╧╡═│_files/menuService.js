/**
 * Created by wx on 17-4-10.
 */
define([], function () {
  var menuData = {
    getMenu: function (bizTypeId) {

      var queryParam = {};
      if (bizTypeId) {
        queryParam['bizTypeId'] = bizTypeId;
      }
      var menus = [];  //拉菜单
      $.ajax({
        url: window.CONTEXT_PATH + '/home/menu',
        data: queryParam,
        async: false,
        type: "GET",
        dataType: 'json',
        success: function (results) {
          var home = {
            "id": "0",
            "parentId": "",
            "title": $("#home_page_title").html(),
            "href": $("#e-home-iframe").attr("src"),
            "appendDivider": false
          };

          menus.push(home);
          for (var i = 0; i < results.length; i++) {
            menus.push(results[i]);
          }
        },
        error:function (event,xhr) {
          if(xhr == 'parsererror'){
            window.open(window.CONTEXT_PATH+'/login', "_self");
          }
        }
      });
      return menus;
    }
  }
  return menuData;
})