/**
 * Created by wx on 17-4-13.
 */
define([
  'text!templates/accountManagement-template.html',
  'views/portraitView',
  'views/bgkConfigView',
  'services/portraitService'
], function (AccountManagementTemplate, portraitView, bgkConfigView, portraitData) {

  var AccountManagementView = Backbone.View.extend({
    el: $("#accountManagement"),
    template: _.template(AccountManagementTemplate),
    initialize: function (options) {
      this.personName = options.personName;
      this.eventBus = options.eventBus;
      this.bizTypeId = options.bizTypeId;
      this.hasAvatar = options.hasAvatar;
      this.defaultAvatar = options.defaultAvatar;
      this.finereportTargetUrl = options.finereportTargetUrl;
      this.defaultSettingStr = {
        en: {
          accountProfile: 'Account Profile',
          accountSetting: "Account Setting",
          portraitSetting: "Portrait Setting",
          bgkSetting: "Background Setting",
          primarySetting: "Primary Setting",
          shortCutSetting: "Shortcut Setting",
          accountLogout: "Log Out",
          switchIdentity: "Switch Identity"
        },
        zh: {
          accountProfile: '我的档案',
          accountSetting: "账户设置",
          portraitSetting: "头像设置",
          bgkSetting: "背景设置",
          primarySetting: "一级菜单设置",
          shortCutSetting: "快捷入口设置",
          accountLogout: "退出",
          switchIdentity: "身份切换"
        }
      };
      this.$el.html(this.template(this.defaultSettingStr[window.LOCALE]));
      this.renderIdentitySwitcher();
      if (this.hasAvatar) {
        this.portraitData = portraitData.getPortrait();
        this.$el.find('#portrait').attr('src', this.portraitData)
      } else {
        this.$el.find('#portrait').attr('src', this.defaultAvatar)
      }

      this.$el.find('.personName').html(this.personName);
      this.$el.find('.accountLogout').attr('href', window.CONTEXT_PATH + '/logout-emitter');
      ;
      this.listenTo(this.eventBus, 'bizType:change', this.changeBiztype);

    },
    changeBiztype: function (bizTypeid) {
      var _self = this;
      if (bizTypeid != undefined) {
        _self.bizTypeId = bizTypeid
      }
    },
    events: {
      'click .accountProfile': 'accountProfile',
      'click .accountSetting': 'accountSetting',
      'click .bgkSetting': 'bgkSetting',
      'click .primarySetting': 'primarySetting',
      'click .shortCutSetting': 'shortCutSetting',
      'click .portraitSetting': 'portraitSetting',
      'click .switchIdentity': 'switchIdentity',
      'click .identity-change': 'identityChange',
      'click .accountLogout': 'accountLogout'
    },
    accountProfile: function (e) {
      e.preventDefault();
      var $anchor = $(e.target);
      if (e.target.tagName != 'A') {
        $anchor = $(e.target).parent('a');
      }
      $anchor.attr('href', window.CONTEXT_PATH + '/my/profile');
      this.eventBus.trigger('fixedMenu:activated', $anchor, e);
    },

    accountSetting: function (e) {
      e.preventDefault();
      var $anchor = $(e.target);
      if (e.target.tagName != 'A') {
        $anchor = $(e.target).parent('a');
      }
      $anchor.attr('href', window.CONTEXT_PATH + '/my/account');
      this.eventBus.trigger('fixedMenu:activated', $anchor, e);
    },

    primarySetting: function (e) {
      this.$el.parents('header').find('#e-home-tab-home').trigger('click');//触发首页

      this.eventBus.trigger('primarySetting:show', this.bizTypeId)
    },
    bgkSetting: function (e) {
      this.$el.parents('header').find('#e-home-tab-home').trigger('click');//触发首页

      this.bgk ? this.bgk.undelegateEvents() : '';
      this.bgk = new bgkConfigView({})
    },
    portraitSetting: function (e) {
      this.$el.parents('header').find('#e-home-tab-home').trigger('click');//触发首页
      this.portrait ? this.portrait.undelegateEvents() : '';
      this.portrait = new portraitView({})
    },
    shortCutSetting: function (e) {
      this.$el.parents('header').find('#e-home-tab-home').trigger('click');//触发首页
      this.eventBus.trigger('shortcut:show')
    },
    renderIdentitySwitcher: function (e) {
      var _self = this;
      _self.$el.find("li.identity").before($("#identity-tpl").html());
    },
    identityChange: function (e) {
      var $e = $(e.target);
      if (e.target.tagName === 'SPAN') {
        $e = $(e.target).closest('a.identity-change');
      }
      var type = $e.attr("value");
      $.post({
        url: window.CONTEXT_PATH + '/individual-setting/save-setting',
        data: JSON.stringify(["navigation-identity", type]),
        contentType: "application/json",
        success: function (res) {
        }
      });
    },
    accountLogout: function (e) {
      var _self = this;
      $.ajax({
        url: _self.finereportTargetUrl + "/logout/cross/domain",//单点登录的报表服务器
        dataType: "jsonp",//跨域采用jsonp方式
        jsonp: "callback",
        timeout: 5000,//超时时间（单位：毫秒）
        success: function (data) {
          /*if (data.status === "success") {
            //登出成功
          }*/
        },
        error: function () {
          // 登出失败（超时或服务器其他错误）
        }
      });
    }
  });
  return AccountManagementView;

});
