define([
      'text!templates/primarySubMenu-template.html'
    ],
    function (primarySubMenuTemplate) {
      var primaryView =  Backbone.View.extend({
        tagName: 'li',
        // className:'primaryLi col-sm-2 col-md-2 hasSubMenus',
        className:'primaryLi hasSubMenus',
        template: _.template(primarySubMenuTemplate),
        initialize: function (options) {
          this.menu = options.menu;
          this.eventBus = options.eventBus;
          this.subMenus = options.subMenus;
          this.num = options.num;
          this.render();
        },
        render: function (codeList) {
          var _self = this;
          var remarks = [];
          var hasNull = false;
          _self.subMenus.forEach(function (item, index) {
            var currentRemark = item.remark;
            if(!currentRemark){
              hasNull = true
            }
            currentRemark && remarks.indexOf(currentRemark) == -1  ? remarks.push(currentRemark) :''
          });
          hasNull ? remarks.push(null) :'';

          this.$el.prepend(this.template({
            menu: _self.menu,
            subMenus: _self.subMenus,
            num: _self.num
          }));
          if(_self.subMenus.length == 0){
            this.$el.addClass("noSubMenus");
            this.$el.click(function (e) {
              if(e.target.tagName === "A"){
                return ;
              }
              var $a = _self.$el.find("a.primary-menu");
              $a.click();
            })
          }

          remarks.forEach(function (remark, index) {
           var currentSubMenus =  _self.subMenus.filter(function (item) {
              return item.remark === remark;
            });

           if(remark){
             _self.$el.find('div.subMenus .subMenusContainer').append('<li  class="list-group-item remark-'+index+' has-remark">' +
                 '<div  class=" text-right title-text left-part title" ><p>'+remark+'</p></div>' +
                 '<div class="right-part"></div>' +
                 '</li>')

           }
           else {
             _self.$el.find('div.subMenus .subMenusContainer').append('<li  class="list-group-item remark-'+index+' no-remark">' +
                 '<div  class=" text-right left-part title"><p></p></div>' +
                 '<div class="right-part"></div> ' +
                 '</li>')
           }

            currentSubMenus.forEach(function (item) {
              if(item.subMenus.length >0){
                // _self.$el.find('div.subMenus').find('.remark-'+index+'').append('<div>'+item.title+'<i class="fa fa-angle-right" ></i></div>')
                item.subMenus.forEach(function (subMenu) {
                  _self.$el.find('div.subMenus').find('.remark-'+index+'').find('.right-part').append('<a  class="primary-subMenu"  href="'+subMenu.href+'" target="_blank">'+subMenu.title+'</a>')
                })

              }else{
                _self.$el.find('div.subMenus').find('.remark-'+index+'').find(".right-part").append('<a  class="primary-subMenu" href="'+item.href+'" target="_blank">'+item.title+'</a>')

              }
            })
          })

        },
        events: {
          'mouseenter': 'open',
          'mouseleave': 'close',
          'click .primary-subMenu': 'subMenu',
          'click .primary-menu': 'menu',
          'click .primary-icon': 'menu'
        },
        open:function (e) {
          var $target = $(e.target);
          $('.subMenus').addClass('hide')
          $target = $target.hasClass('primaryLi') ? $target : $target.parents('li.primaryLi') ;
          $target.find('.primary-img-hover').removeClass('hide');
          $target.find('.subMenus').removeClass('hide');

        },

        close:function (e) {
          var $target = $(e.target);
          $target = $target.hasClass('primaryLi') ? $target : $target.parents('li.primaryLi') ;
          $target.find('.primary-img-hover').addClass('hide');
          $target.find('.subMenus').addClass('hide');

        },
        subMenu:function (e) {
          var $target = $(e.target);
          this.eventBus.trigger('primarySubMenu:click', $target, e);
        },
        menu:function (e) {
          var $target = $(e.target);
          var $parent = $target.parents('li.primaryLi');
          $target = $parent.find('a.primary-menu')
          if($parent.hasClass('hasSubMenus')){
            return
          }
          this.eventBus.trigger('primarySubMenu:click', $target, e);
        }
      });
      return primaryView;
    })