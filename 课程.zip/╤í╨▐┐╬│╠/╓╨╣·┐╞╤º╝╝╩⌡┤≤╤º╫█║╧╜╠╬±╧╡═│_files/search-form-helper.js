$(function () {

  //截取queryString的内容返回数组
  var matchQueryString = function(url){
    var result = {};

    var queryStringArray = url.match(new RegExp("[\?\&][^\?\&]+=[^\?\&]+","g"));
    if(queryStringArray == null){
      return {};
    }

    for(var i = 0; i < queryStringArray.length; i++){
      queryStringArray[i] = queryStringArray[i].substring(1);

      var arr = queryStringArray[i].split("=");

      if (result[arr[0]]) {
        if (!result[arr[0]].push) {
          result[arr[0]] = [result[arr[0]]];
        }
        result[arr[0]].push(decodeURIComponent(arr[1]));
      } else {
        result[arr[0]] = decodeURIComponent(arr[1]);
      }
    }

    return result;
  };

  $.fn.extend({
    search: function(url) {
      if (this.searchTable.isLoading()) {
        return false;
      }

      var urlPrefix = url;
      if (!urlPrefix) {
        urlPrefix = this.searchTable.getUrl();
      }

      if (urlPrefix.indexOf("?") != -1) {
        urlPrefix = urlPrefix.substring(0, urlPrefix.indexOf("?"));
      }
      var ajaxUrl = urlPrefix + this.getQueryString(true);

      this.searchTable.changeURL(ajaxUrl);
    },



    /**
     * @param searchTable
     * @param currentURI
     * @param updateHistory         true/false
     * @param searchEvents          ['#submit:submit', '#id/.class:change']
     */
    initialize: function (searchTable, currentURI, updateHistory, searchEvents) {
      this.searchTable = searchTable;
      this.updateHistory = updateHistory;

      var _self = this;

      this.fillInFormByQueryString(currentURI);
      $.each(searchEvents, function() {
        var selector = this.split(":")[0];
        var searchEvent = this.split(":")[1];

        //自定义的change学期的事件
        if (searchEvent === "semester-change") {
          $(selector + "").on("change", function (event) {
            event.preventDefault();
            window.localStorage.setItem("current_semester", $(selector + "").val());
            _self.search(semesterURIUtil(_self.searchTable.getUrl(), '/search', $(selector + "").val()));
          })
        } else if (searchEvent === "batch-change") {
          //自定义的change批次的事件
          $(selector + "").on("change", function (event) {
            event.preventDefault();
            _self.search(_self.searchTable.getUrl());
          })
        } else {
          $(selector + "").on(searchEvent, function (event) {
            if (!_self.valid()) {
              return;
            }
            event.preventDefault();
            _self.search();
          })
        }

      });

    },

    /**
     * 根据form中填写的内容生成queryString
     * @param initPageInfo 若为true，则初始化page当前页信息
     * @returns {*|jQuery}
     */
    getQueryString: function(initPageInfo) {

      var serializeArray = $(this).serializeArray();
      var new_serializeArray = [];
      for (var i=0; i < serializeArray.length; i++) {
        if (serializeArray[i].value && serializeArray[i].value.trim()) {
          new_serializeArray.push(serializeArray[i]);
        }
      }
      var queryString = $.param(new_serializeArray).replace(/\+/g, '%20');

      var $table = $(this.searchTable);
      var json = $table.semiAutoTable("getTableJson");

      if (json._page_) {
        var current_page = initPageInfo ? 1 : json._page_.currentPage;

          queryString += (queryString ? "&" : "") + "queryPage__=" + encodeURIComponent(current_page + ","
              + (localStorage.getItem('_page_rowsPerPage') ? localStorage.getItem('_page_rowsPerPage') : json._page_.rowsPerPage));
      }

      if (json._sorts_ && json._sorts_.length > 0) {
        queryString += (queryString ? "&" : "") + "sort__=" + encodeURIComponent(json._sorts_[0].field + "," + json._sorts_[0].typeString.toLowerCase());
      }
      return queryString ? ("?" + queryString) : "";
    },


    /**
     * 填充form的内容
     * @param url
     */
    fillInFormByQueryString: function(url){
      var searchConditionArray = matchQueryString(url);
      for (var key in searchConditionArray) {
        var $formCondition = $(this).find("[name='"+key+"']");

        if ($formCondition[0] && $formCondition[0].selectize) {

          $formCondition[0].selectize.addItem(searchConditionArray[key]);
        } else if ($formCondition.hasClass('selectpicker') || $formCondition.hasClass('selectpic')) {
          $formCondition.selectpicker();
          $formCondition.selectpicker('val', searchConditionArray[key]);
          $formCondition.selectpicker('refresh');
          var num = 1;
          if (typeof searchConditionArray[key] === 'object') {
            num = searchConditionArray[key].length;
          }
          $formCondition.parent().find('.filter-option').text('已选择' + num + '项');
        } else {

          $formCondition.val(decodeURIComponent(searchConditionArray[key]));
        }
      }

    },

    getQueryStringByUrl: function(url) {

      var queryString = "";
      if (url.indexOf("?") != -1 && url.substring(url.indexOf("?")+1)) {
        queryString = url.substring(url.indexOf("?"));
      } else {
        queryString = "?" + $(this).serialize();
      }

      if (localStorage.getItem('_page_rowsPerPage')) {

        var _page_rowsPerPage = localStorage.getItem('_page_rowsPerPage');
        if (queryString.indexOf("?") == -1) {

          queryString += "?queryPage__=" + encodeURIComponent("1," + _page_rowsPerPage);

        }else if (queryString.indexOf("queryPage__") == -1 && queryString.length > 1) {

          queryString += "&queryPage__=" + encodeURIComponent("1," + _page_rowsPerPage);

        } else {
          var pageInfo = "";
          if ( queryString.match(/queryPage__=(.*?)\&/) ) {

            pageInfo = decodeURIComponent(queryString.match(/queryPage__=(.*?)\&/)[0].replace("queryPage__=", ""));
            queryString = queryString.replace(/queryPage__=(.*?)\&/, "queryPage__=" + encodeURIComponent(pageInfo.split(",")[0] + "," + _page_rowsPerPage) + "&");

          } else if ( queryString.match(/queryPage__=(.*?)$/) ) {

            pageInfo = decodeURIComponent(queryString.match(/queryPage__=(.*?)$/)[0].replace("queryPage__=", ""));
            queryString = queryString.replace(/queryPage__=(.*?)$/, "queryPage__=" + encodeURIComponent(pageInfo.split(",")[0] + "," + _page_rowsPerPage));

          }
        }
      }
      return queryString;
    },

    /**
     * 初始化分页信息
     */
    initSearchPageSize: function () {
      if (localStorage.getItem('_page_rowsPerPage')) {
        this.append('<input type="text" class="hide" id="localPage" name = "queryPage__"/>');
        var localStorage_rowsPerPage = Number(localStorage.getItem('_page_rowsPerPage'));
        $("#localPage").val(1 + "," + localStorage_rowsPerPage);
      }
    }
  });
});