/**
 * Created by wx on 17-4-10.
 */
define([
      'models/menu',
      'collections/menus',
      'views/shortcutView',
      'views/primaryMenusView',
      'services/menuService',
      'views/primaryConfigView',
      'services/primaryMenuService'
    ],
    function (Menu, menus, ShortcutView, primaryMenusView, MenuService, primaryConfigView, primaryMenuService) {

      var MenuView = Backbone.View.extend({
        el: $("#e-top-menu"),
        initialize: function (options) {
          this.eventBus = options.eventBus;
          this.bizType = options.bizType;
          if(!this.bizType){
            this.bizType = {id:null}
          }
          var _self = this;

          this.shortcutView = new ShortcutView({
            eventBus: _self.eventBus,
            bizTypeId: _self.bizType.id
          });

          this.initPrimaryCodes = primaryMenuService.getPermCodes(this.bizType.id);

          this.primaryMenusView = new primaryMenusView({
            eventBus: _self.eventBus,
            bizTypeId: _self.bizType.id,
            initPrimaryCodes: _self.initPrimaryCodes
          });

          this.primaryConfigView = new primaryConfigView({
            eventBus: _self.eventBus,
            bizTypeId: _self.bizType.id,
            menus: _self.menus,
            initPrimaryCodes: _self.initPrimaryCodes
          });

          this.render();
          this.listenTo(this.eventBus, 'bizType:change', this.render);
          // this.listenTo(this.eventBus, 'tab:activated', this.updateMenu);
          this.listenTo(this.eventBus, 'tab:activated', this.disabledMenu);
        },
        render: function (biztypeid) {
          var _self = this;
          var bizTypeId = _self.bizType.id;
          if (biztypeid != undefined) {
            bizTypeId = biztypeid
          }
          var menus = MenuService.getMenu(bizTypeId);
          this.initMenu(menus, "");

          this.$el.parents('.e-header').find('#saveMenus').val(JSON.stringify(menus));

          menus.splice(0, 1);

          var initPrimaryCodes = primaryMenuService.getPermCodes(bizTypeId);

          this.shortcutView.menus = menus;
          this.shortcutView.render(bizTypeId);
          this.primaryMenusView.menus = menus;
          this.primaryMenusView.initPrimaryCodes = initPrimaryCodes;
          this.primaryMenusView.render(bizTypeId);

          this.primaryConfigView.menus = menus;
          this.primaryConfigView.initPrimaryCodes = initPrimaryCodes;

        },
        events: {
          'click .drop_submenu': 'clickSubMenu'

        },
        initMenu: function (menus, initParentId) {
          var _self = this;

          this.$el.html("");
          var $home_Baseli = $('<li><a href="#">Link <span class="sr-only"></span></a></li>');
          var $home_DropDownli = $(' <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a><ul class="dropdown-menu"><li>1</li></ul></li>')

          var $home_li = $("<li class='dropdown home dropdown-hover'></li>");
          var $home_a = $("<a></a>").addClass("dropdown-toggle").addClass("toggle-menu")
              .attr("role", "button").attr("data-toggle", "dropdown")
              .attr("aria-haspopup", true).attr("aria-expanded", false)
              .attr("href", "#");
              // .append('<span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>')

          var $home_ul = $("<ul><li class='search-li'><input class='form-control' id='menu-search' placeholder='请输入菜单搜索' style='width: 90%;margin: 0 auto'/><i class='fa fa-times-circle hide' id='clear-search-input' style='position: relative; top:-25px;left: 135px;'></i></li></ul>")
              .addClass("dropdown-menu").attr('aria-labelledby', 'drop_0');

          var allMenus = this.getMenus(menus, initParentId);
          if (allMenus && allMenus.length != 0) {
            $.each(allMenus, function (i, menu) {
              $home_ul.append(menu);
            });
            $home_li.append($home_a.append("")).append($home_ul);
            $home_li.find("[appendDivider=true]").each(function () {
              $(this).closest('li').after("<li class='divider'></li>");
            });
            this.$el.append($home_li);
          }

          $('#menu-search').on('input', function (e) {
            _self.menuSearch(e);
          });
          $('#clear-search-input').on('click', function (e) {
            var $target = $(e.target);
            var $parent = $target.parents('ul.dropdown-menu');
            $parent.find('.search-result').remove();
            $parent.find('.no-menu-find-tip').remove();

            var $lis = $parent.find('li');
            $target.prev().val('');
            $lis.show();
            $('#clear-search-input').addClass('hide');
          })

          $(".dropdown-hover a:first").dropdownHover({
            changePosition: true
          });


          $("[target=e-home-iframe]").click(function (e) {
            _self.eventBus.trigger('activate:hometab', e);

            $("li.dropdown-hover").removeClass("open");
          });

        },
        menuSearch: function (e) {
          var $target = $(e.target);
          var value = $target.val();
          var $parent = $target.parents('ul.dropdown-menu');
          $parent.find('.search-result').remove();
          var $lis = $parent.find('li');

          var showNum = $lis.length - 1;
          $lis.each(function (index, li) {
            if (index == 0) {
              return;
            }
            if (value) {
              $('#clear-search-input').removeClass('hide')
              if ($(li).find('a').length == 0 || $(li).find('>a').text().indexOf(value) === -1) {
                showNum--;
              } else {
                if (!$(li).hasClass('dropdown-submenu')) {
                  var temp = $(li).clone();
                  $parent.append(temp.addClass('search-result').show())
                }
              }
              $(li).hide();

            } else {
              $('#clear-search-input').addClass('hide')
              $(li).show();
            }

          });
          if (showNum === 0 && $target.parents('ul').find('.no-menu-find-tip').length == 0) {
            $parent.append('<label class="no-menu-find-tip">没有找到相关菜单</label>')
          } else if (showNum != 0) {
            $parent.find('.no-menu-find-tip').remove();
          }

        },

        getMenus: function (menus, parentID) {
          var $iframeContainer = $('#e-op-area .e-op-area-iframe-container');
          var iframeHomeName = "e-home-iframe";
          var $iframeHome = $iframeContainer.find('iframe[name=' + iframeHomeName + ']');
          var home_src = $iframeHome.attr("src");
          var _self = this;
          var $home_a = $("<a></a>").addClass("dropdown-toggle")
              .attr("role", "button").attr("data-toggle", "dropdown")
              .attr("aria-haspopup", true).attr("aria-expanded", false)
              .attr("href", "#");

          return menus.filter(function (node) {
            return ( node.parentId === parentID );
          }).map(function (node) {
            var exists = menus.some(function (childNode) {
              return childNode.parentId === node.id;
            });

            var $ul = $("<ul></ul>").addClass("dropdown-menu").attr('aria-labelledby', "drop_" + node.id);
            var subMenu = (exists) ? $ul.append(_self.getMenus(menus, node.id)) : "";
            var $li = $("<li></li>");
            var $a = $("<a></a>");
            $a.attr("id", "drop_" + node.id);
            $a.attr("class", "drop_submenu");
            $a.attr("href", node.href);
            $a.text(node.title);

            //如果是home页面设置target为e-home-iframe
            if (node.href === home_src) {
              $a.attr("target", "e-home-iframe");
              $home_a.text(node.title);
            }
            if (node.parentId) {
              $a.attr("parentId", "drop_" + node.parentId);
            }
            $a.attr('appendDivider', node.appendDivider);
            if (subMenu != "") {
              $li.addClass("dropdown-submenu");
            }
            return $li.append($a).append(subMenu);
          });
        },

        disabledMenu: function ($anchor) {
          this.$el.find("li").removeClass("disabled");
          $anchor.closest("li").addClass("disabled");
        },

        updateMenu: function ($anchor) {
          var drop_parentId = $anchor.attr("parentId");

          var $menu_list = this.$el.find("ul[aria-labelledby='" + drop_parentId + "']").removeAttr("style");
          if ($menu_list.length != 0) {
            var $new_li = $("<li></li>").addClass("dropdown children dropdown-hover");
            var $new_a = $("<a></a>").addClass("dropdown-toggle")
                .attr("role", "button").attr("data-toggle", "dropdown")
                .attr("aria-haspopup", true).attr("aria-expanded", false)
                .text($anchor.text());

            $new_li.append($new_a)

            if ($menu_list.find("li").length > 1) {
              $new_a.append("<span class='caret'></span>");
              $new_li.append($menu_list.clone(true));
            }

            this.$el.find("li:first").after($new_li);


            //查找上一级菜单
            var $parent_anchor = this.$el.find("a[id='" + drop_parentId + "']");
            this.updateMenu($parent_anchor);
          } else {
            this.$el.find("li a:first").text($anchor.text()).append("<span class='caret'></span>");
          }

          $(".dropdown-hover a[class='dropdown-toggle']").dropdownHover({
            changePosition: true
          });

        },

        clickSubMenu: function (e, queryString) {
          var _self = this;
          var $this = $(e.target);

          var $body = $("body");
          if (!$this.attr('href') || $this.attr('href') == '#') {
            e.target.style.backgroundColor = 'transparent';
            $this.siblings().show();
            return false;
          }

          e.preventDefault();
          this.$el.find("li.children").remove();
          // _self.updateMenu($this);

          $body.find(".dropdown-toggle-hover").removeClass("dropdown-toggle-hover");
          this.eventBus.trigger('menu:activated', $this, e, queryString);

          //disabled当前菜单
          _self.disabledMenu(this.$el.find("a[id='" + $this.attr("id") + "']"));

        }

      });
      return MenuView;

    });